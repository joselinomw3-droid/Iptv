package com.example.iptvplayer

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.URL

 data class Channel(val name:String, val url:String, val group:String, val logo:String? = null)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { IPTVApp(this) } }
}

@Composable
fun IPTVApp(context: Context) {
 var playlistUrl by remember { mutableStateOf("") }
 var channels by remember { mutableStateOf(listOf<Channel>()) }
 var selected by remember { mutableStateOf<Channel?>(null) }
 var query by remember { mutableStateOf("") }
 var group by remember { mutableStateOf("Todos") }
 var favorites by remember { mutableStateOf(setOf<String>()) }
 var message by remember { mutableStateOf("") }
 var showUrl by remember { mutableStateOf(false) }
 val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
   if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.onSuccess { text ->
     channels = parseM3U(text ?: ""); message = "${channels.size} canais carregados"
   }.onFailure { message = "Não foi possível ler a playlist" }
 }
 val groups = listOf("Todos") + channels.map { it.group }.filter { it.isNotBlank() }.distinct().sorted()
 val filtered = channels.filter { (group == "Todos" || it.group == group) && it.name.contains(query, true) }

 MaterialTheme(colorScheme = darkColorScheme()) {
  Scaffold(topBar = { TopAppBar(title={Text("IPTV Player")}) }) { pad ->
   Column(Modifier.padding(pad).fillMaxSize()) {
    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
      Button(onClick={picker.launch(arrayOf("*/*"))}) { Text("Abrir M3U") }
      OutlinedButton(onClick={showUrl=true}) { Text("URL da playlist") }
    }
    if (showUrl) {
      Row(Modifier.padding(horizontal=12.dp), verticalAlignment=Alignment.CenterVertically) {
       OutlinedTextField(playlistUrl, {playlistUrl=it}, Modifier.weight(1f), label={Text("URL M3U/M3U8")})
       Spacer(Modifier.width(8.dp)); Button(onClick={
         Thread { runCatching { URL(playlistUrl).readText() }.onSuccess { t -> channels=parseM3U(t); message="${channels.size} canais carregados" }.onFailure { message="Erro ao baixar playlist" } }.start(); showUrl=false
       }) { Text("Carregar") }
      }
    }
    if (selected != null) Player(selected!!, context)
    if (message.isNotBlank()) Text(message, Modifier.padding(horizontal=12.dp, vertical=6.dp))
    OutlinedTextField(query,{query=it},Modifier.fillMaxWidth().padding(horizontal=12.dp),label={Text("Buscar canal")})
    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
      groups.take(6).forEach { g -> FilterChip(selected=group==g,onClick={group=g},label={Text(g)}) }
    }
    LazyColumn(Modifier.fillMaxSize()) {
      items(filtered) { c ->
       ListItem(headlineContent={Text(c.name)}, supportingContent={Text(c.group.ifBlank { "Sem categoria" })},
        trailingContent={Text(if(favorites.contains(c.url)) "★" else "☆", style=MaterialTheme.typography.headlineSmall, modifier=Modifier.clickable { favorites = if(favorites.contains(c.url)) favorites-c.url else favorites+c.url })},
        modifier=Modifier.clickable { selected=c })
       HorizontalDivider()
      }
    }
   }
  }
 }
}

@Composable fun Player(channel: Channel, context: Context) {
 val player = remember(channel.url) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(channel.url)); prepare(); playWhenReady=true } }
 DisposableEffect(player) { onDispose { player.release() } }
 Column(Modifier.fillMaxWidth().padding(12.dp)) {
  Text(channel.name, style=MaterialTheme.typography.titleMedium, modifier=Modifier.padding(bottom=6.dp))
  AndroidView(factory={ PlayerView(it).apply { this.player=player; useController=true } }, modifier=Modifier.fillMaxWidth().height(220.dp))
 }
}

fun parseM3U(text:String): List<Channel> {
 val lines=text.lines(); val out=mutableListOf<Channel>(); var info=""; var name=""; var group=""; var logo:String?=null
 for(line0 in lines) { val line=line0.trim();
  if(line.startsWith("#EXTINF", true)) { info=line; name=line.substringAfter(",", "Canal").trim(); group=Regex("group-title=\"([^\"]*)\"").find(line)?.groupValues?.getOrNull(1).orEmpty(); logo=Regex("tvg-logo=\"([^\"]*)\"").find(line)?.groupValues?.getOrNull(1) }
  else if(line.isNotBlank() && !line.startsWith("#") && info.isNotBlank()) { out += Channel(name, line, group, logo); info="" }
 }
 return out
}
